RAM-SAWIT — PHP + MySQL
=======================

FITUR
- Login dengan session PHP dan peran admin/warga.
- Dashboard membaca data dari MySQL.
- Admin: CRUD harga TBS, desa, RAM, pengumuman, berita, pengguna, pengaturan.
- Laporan berdasarkan rentang tanggal dan cetak.
- Warga: melihat harga terbaru, berita, pengumuman, dan kalkulator panen.
- Navigasi ikon Font Awesome, layout responsif, pencarian tabel.
- Query menggunakan PDO prepared statements dan password_verify/password_hash.

INSTALASI XAMPP
1. Ekstrak folder RAM-Sawit ke C:\\xampp\\htdocs\\RAM-Sawit
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka http://localhost/phpmyadmin
4. Pilih Import, lalu impor file database/ram_sawit.sql.
5. Pastikan config/database.php cocok dengan akun MySQL Anda (default XAMPP: root tanpa password).
6. Buka http://localhost/RAM-Sawit/

AKUN AWAL
Admin: admin@ramsawit.com / admin123
Warga: warga@ramsawit.com / warga123

PENTING
- Jika hash kata sandi seed tidak diterima oleh lingkungan Anda, jalankan skrip PHP sementara berikut dari folder proyek lalu hapus skrip tersebut:
  <?php echo password_hash('admin123', PASSWORD_DEFAULT), PHP_EOL, password_hash('warga123', PASSWORD_DEFAULT);
  Salin hash yang dihasilkan ke kolom password untuk masing-masing email melalui phpMyAdmin.
- Data desa, RAM, dan harga awal adalah data contoh dari desain HTML yang Anda kirim, bukan konfirmasi data harga resmi/terkini. Perbarui dari admin sebelum digunakan sebagai informasi resmi.
- Untuk keamanan produksi, ganti kata sandi awal, aktifkan HTTPS, tambahkan proteksi CSRF dan kebijakan backup.
- Data awal desa telah disesuaikan menjadi enam desa Kecamatan Singkohor: Lae Pinang, Lae Sipola, Mukti Jaya (termasuk Mukti Harapan), Pea Jambu, Singkohor, dan Sri Kayu. Nama RAM serta harga awal pada SQL adalah data contoh dan perlu diperbarui sesuai data lapangan.

PENGELOLAAN FITUR OLEH ADMIN
- Buka menu Pengaturan > Kendali Fitur & Navigasi.
- Admin dapat menonaktifkan atau mengaktifkan tautan fitur yang sudah tersedia, membatasi akses menu untuk Admin/Warga, mendaftarkan path fitur PHP baru, dan menghapus tautan dari navigasi.
- Fitur baru didaftarkan dalam keadaan nonaktif. Developer perlu membuat dan menguji file PHP-nya terlebih dahulu, lalu admin dapat mengaktifkannya.
- Menghapus fitur hanya menghapus entri navigasi, bukan file PHP atau data database.
- Pada pembaruan dari database lama, tabel fitur_web dibuat otomatis saat aplikasi diakses. Jika melakukan instalasi baru, database/ram_sawit.sql juga sudah memuat tabel dan menu bawaan.

FITUR PEMELIHARAAN TAMBAHAN
- Laporan rekap dengan watermark, tanggal/waktu cetak, ringkasan data, grafik rata-rata per desa, dan cetak PDF melalui browser.
- Log Aktivitas untuk meninjau perubahan yang dicatat sistem.
- Backup Database untuk mengunduh salinan SQL; simpan di tempat aman karena berisi data sensitif.
- Setelah pembaruan, uji login admin/warga, input harga, filter laporan, dan cetak A4.
