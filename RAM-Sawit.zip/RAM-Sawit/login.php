<?php
require __DIR__.'/config/database.php';
if (logged_in()) { header('Location: dashboard.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim($_POST['email'] ?? ''); $password=$_POST['password'] ?? ''; $role=$_POST['role'] ?? 'user';
    $q=$pdo->prepare('SELECT id,nama,email,password,role,desa_id FROM users WHERE email=? LIMIT 1'); $q->execute([$email]); $u=$q->fetch();
    if ($u && password_verify($password,$u['password']) && ($role===$u['role'])) {
        unset($u['password']); session_regenerate_id(true); $_SESSION['user']=$u; log_activity($pdo,'Login ke sistem');
        header('Location: dashboard.php'); exit;
    } else $error='Email, kata sandi, atau jenis akun tidak sesuai.';
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#123c2b"><link rel="icon" type="image/png" sizes="128x128" href="/RAM-Sawit/assets/images/agroinfo-favicon.png?v=1"><link rel="shortcut icon" href="/RAM-Sawit/assets/images/agroinfo-favicon.ico?v=1"><title>Masuk · RAM Sawit</title><link rel="stylesheet" href="assets/css/style.css?v=20261025-theme-custom"><style>:root{--theme-primary:<?=e(setting($pdo,'warna_utama','#164E78'))?>;--theme-accent:<?=e(setting($pdo,'warna_aksen','#38BDF8'))?>;--theme-bg:<?=e(setting($pdo,'warna_latar','#F3F9FD'))?>;--red:var(--theme-accent);--amber:var(--theme-accent);--forest:var(--theme-primary);--bg:var(--theme-bg);--blue:var(--theme-accent);--blue-deep:var(--theme-primary)}.login-page{background:radial-gradient(circle at top right,var(--theme-accent) 0,var(--theme-primary) 48%,color-mix(in srgb,var(--theme-primary),#071b2b 30%) 100%)}.login-brand{background:linear-gradient(135deg,var(--theme-primary),color-mix(in srgb,var(--theme-primary),var(--theme-accent) 38%),var(--theme-primary))}.login-brand .brand-icon,.login-form .btn.primary{background:var(--theme-accent)}</style><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"></head>
<body class="login-page">
<main class="login-shell">
  <section class="login-visual" aria-label="Ilustrasi perkebunan kelapa sawit dan petani">
    <div class="visual-shade"></div>
    <a class="visual-brand" href="index.php"><span class="visual-logo"><i class="fa-solid fa-seedling"></i></span><span>RAM <b>SAWIT</b></span></a>
    <div class="visual-copy">
      <span class="visual-eyebrow"><i class="fa-solid fa-leaf"></i> INFORMASI SAWIT SINGKOHOR</span>
      <h1>Harga Jelas,<br><em>Petani Lebih Berdaya.</em></h1>
      <p>Akses informasi harga Tandan Buah Segar (TBS), kabar pertanian, dan informasi RAM dalam satu tempat.</p>
      <div class="visual-points"><span><i class="fa-solid fa-chart-line"></i> Pantau informasi harga</span><span><i class="fa-solid fa-location-dot"></i> Terhubung dengan desa</span></div>
    </div>
    <div class="visual-bottom"><span><i class="fa-solid fa-sun"></i> Tumbuh bersama petani</span><span>KEBUN · KOMUNITAS · KEMAJUAN</span></div>
    <div class="visual-orb orb-one"></div><div class="visual-orb orb-two"></div>
  </section>
  <section class="login-side">
    <div class="login-card">
      <div class="login-brand"><div class="brand-icon"><i class="fa-solid fa-tree"></i></div><h2>Selamat Datang</h2><p>Masuk ke sistem informasi RAM Sawit</p><span class="pill"><i class="fa-solid fa-shield-halved"></i> AKSES AMAN & TERPUSAT</span></div>
      <form method="post" class="login-form">
        <?php if($error): ?><div class="alert error"><i class="fa-solid fa-circle-exclamation"></i> <?=e($error)?></div><?php endif; ?>
        <div class="form-intro"><h3>Masuk ke akun Anda</h3><p>Pilih jenis akun, lalu masukkan data login.</p></div>
        <label for="role">Masuk sebagai</label><div class="select-wrap"><i class="fa-solid fa-users"></i><select id="role" name="role"><option value="admin">Panel Admin</option><option value="user">Panel Warga</option></select></div>
        <label for="email">Email</label><div class="input-icon"><i class="fa-regular fa-envelope"></i><input id="email" name="email" type="email" placeholder="nama@email.com" required autocomplete="username"></div>
        <label for="password">Kata sandi</label><div class="input-icon"><i class="fa-solid fa-lock"></i><input id="password" name="password" type="password" placeholder="Masukkan kata sandi" required autocomplete="current-password"><button class="password-toggle" type="button" aria-label="Tampilkan kata sandi" aria-pressed="false" id="passwordToggle"><i class="fa-regular fa-eye"></i></button></div>
        <button class="btn primary full login-submit" type="submit">Masuk ke Dashboard <i class="fa-solid fa-arrow-right"></i></button>
        <div class="login-help"><i class="fa-solid fa-circle-info"></i><span>Gunakan akun yang telah terdaftar. Hak akses admin dan warga akan disesuaikan dengan akun Anda.</span></div>
      </form>
    </div>
    <footer class="login-footer"><a class="back-home" href="index.php"><i class="fa-solid fa-arrow-left"></i> Kembali ke landing page</a><span>© <?=date('Y')?> RAM Sawit · Singkohor</span></footer>
  </section>
</main>
<script>
(()=>{const p=document.getElementById('password'),b=document.getElementById('passwordToggle');if(p&&b){b.addEventListener('click',()=>{const show=p.type==='password';p.type=show?'text':'password';b.setAttribute('aria-pressed',String(show));b.setAttribute('aria-label',show?'Sembunyikan kata sandi':'Tampilkan kata sandi');b.innerHTML=show?'<i class="fa-regular fa-eye-slash"></i>':'<i class="fa-regular fa-eye"></i>';p.focus()})}})();
</script>
</body></html>
