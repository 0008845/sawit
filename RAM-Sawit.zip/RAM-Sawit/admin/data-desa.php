<?php
require __DIR__.'/../config/database.php'; require_admin(); require __DIR__.'/../includes/crud.php';
render_crud($pdo,['title'=>'Data Desa','table'=>'desa','fields'=>['nama'=>['label'=>'Nama desa','required'=>true],'kecamatan'=>['label'=>'Kecamatan','default'=>'Singkohor'],'alamat'=>['label'=>'Keterangan / alamat'],'status'=>['label'=>'Status','options'=>['Aktif'=>'Aktif','Nonaktif'=>'Nonaktif'],'default'=>'Aktif']],'columns'=>['id'=>'ID','nama'=>'Nama Desa','kecamatan'=>'Kecamatan','alamat'=>'Keterangan','status'=>'Status']]);
