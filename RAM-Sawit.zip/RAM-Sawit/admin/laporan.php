<?php
require __DIR__.'/../config/database.php'; require_admin();
$title='Laporan'; $subtitle='Rekap harga TBS dengan watermark dan ringkasan data aktual';
$from=$_GET['from']??date('Y-m-01'); $to=$_GET['to']??date('Y-m-d');
$validFrom=DateTime::createFromFormat('Y-m-d',$from); $validTo=DateTime::createFromFormat('Y-m-d',$to);
if(!$validFrom || $validFrom->format('Y-m-d')!==$from || !$validTo || $validTo->format('Y-m-d')!==$to || $from>$to){$from=date('Y-m-01');$to=date('Y-m-d');}
$q=$pdo->prepare('SELECT h.id,h.tanggal,d.nama desa,r.nama ram,h.harga_per_kg,h.catatan FROM harga_tbs h JOIN desa d ON d.id=h.desa_id LEFT JOIN ram r ON r.id=h.ram_id WHERE h.tanggal BETWEEN ? AND ? ORDER BY h.tanggal DESC,d.nama,r.nama');$q->execute([$from,$to]);$rows=$q->fetchAll();
$total=count($rows);$avg=$total?array_sum(array_map(fn($r)=>(float)$r['harga_per_kg'],$rows))/$total:0;
$desaCount=count(array_unique(array_column($rows,'desa')));$ramCount=count(array_filter(array_unique(array_column($rows,'ram')),fn($v)=>$v!==null&&$v!==''));
$reportNo='RS-'.date('Ymd-His');$printDate=date('l, d F Y');$dayNames=['Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu','Sunday'=>'Minggu'];$monthNames=[1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];$now=date('d').' '.$monthNames[(int)date('n')].' '.date('Y');$printDate=($dayNames[date('l')]??date('l')).', '.$now;
include __DIR__.'/../includes/layout.php';
?>
<style>
.report-toolbar{display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin-bottom:16px}.report-toolbar .field{margin:0}.report-paper{position:relative;background:#fff;color:#123b59;border:1px solid #c9e0ef;border-radius:12px;padding:26px;overflow:hidden;box-shadow:0 8px 25px #164e780c}.report-paper:before{content:'RAM SAWIT';position:absolute;top:42%;left:14%;font-size:clamp(50px,9vw,110px);font-weight:900;letter-spacing:5px;color:rgba(22,134,201,.075);transform:rotate(-28deg);white-space:nowrap;pointer-events:none}.report-paper>*{position:relative}.report-head{display:flex;justify-content:space-between;align-items:center;gap:18px;border-bottom:3px solid #1686c9;padding-bottom:16px}.report-brand{display:flex;gap:13px;align-items:center}.report-logo{width:62px;height:62px;border-radius:50%;background:#e0f2fe;border:3px solid #1686c9;display:grid;place-items:center;color:#075985;font-size:28px;flex-shrink:0}.report-brand h2{margin:0;color:#075985;font-size:clamp(22px,3vw,34px);letter-spacing:1px}.report-brand p{margin:3px 0;color:#52718a;font-size:12px}.report-meta{font-size:11px;line-height:1.8;color:#234d6d}.report-title{text-align:center;padding:18px 0 14px}.report-title h3{margin:0;color:#075985;font-size:clamp(17px,2.3vw,25px)}.report-title p{margin:6px 0 0;color:#52718a}.report-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:8px 0 18px}.report-metric{border:1px solid #b9def4;border-radius:9px;padding:13px;background:linear-gradient(145deg,#fff,#f3faff);min-width:0}.report-metric span{font-size:10px;color:#52718a;text-transform:uppercase;font-weight:800;display:block}.report-metric b{display:block;font-size:clamp(17px,2vw,25px);margin-top:5px;color:#075985;overflow-wrap:anywhere}.report-section-title{background:linear-gradient(90deg,#075985,#1686c9);color:#fff;border-radius:7px 7px 0 0;padding:10px 13px;font-size:13px;font-weight:800}.report-table{width:100%;border-collapse:collapse;font-size:11px}.report-table th{background:#e2f3fd;color:#164e78;text-align:left}.report-table th,.report-table td{padding:8px 9px;border:1px solid #c7e2f3}.report-table tbody tr:nth-child(even){background:#f3faff}.report-bottom{display:block;margin-top:15px}.report-info-box{border:1px solid #d7e0e8;border-radius:5px;padding:15px;background:#fff;min-width:0;max-width:100%}.report-info-box h4{margin:0 0 10px;color:#173f5b;font-size:11px;border-bottom:1px solid #e1e8ee;padding-bottom:9px}.report-info-box p{font-size:10.5px;margin:7px 0;color:#42576a;line-height:1.55}.report-sign{margin:20px 0 0 auto;text-align:center;width:190px;font-size:11px}.report-sign-line{margin-top:45px;border-bottom:1px solid #62829a}.report-footer{margin-top:18px;padding-top:12px;border-top:2px solid #9dd6f5;display:flex;justify-content:space-between;gap:10px;font-size:10px;color:#52718a}.report-empty{padding:22px;text-align:center;color:#64748b}@media(max-width:800px){.report-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.report-head{align-items:flex-start;flex-direction:column}.report-paper{padding:14px}.report-table{font-size:10px}.report-table th,.report-table td{padding:6px 5px}}@media print{@page{size:A4 portrait;margin:10mm}body{background:#fff!important}.sidebar,.topbar,.report-toolbar,.mobile-toggle,.desktop-sidebar-toggle{display:none!important}.main,.content{margin:0!important;padding:0!important;width:100%!important}.report-paper{box-shadow:none;border:0;border-radius:0;padding:0}.report-paper:before{position:fixed}.report-summary{grid-template-columns:repeat(4,minmax(0,1fr))}.report-bottom{grid-template-columns:1.15fr 1fr}.report-table{font-size:9px}.report-table th,.report-table td{padding:5px 6px;break-inside:avoid}.report-section-title,.report-table th{-webkit-print-color-adjust:exact;print-color-adjust:exact}.report-paper a{color:inherit;text-decoration:none}}

/* Corporate report presentation */
.report-paper{border:1px solid #d7e0e8;border-radius:4px;padding:30px;background:#fff;color:#1f2937;box-shadow:0 8px 28px rgba(15,39,64,.08);font-family:Arial,Helvetica,sans-serif}
.report-paper:before{color:rgba(15,80,125,.045);font-size:clamp(56px,10vw,118px);letter-spacing:7px}
.report-head{border-bottom:4px solid #174a6e;padding-bottom:18px;align-items:flex-start}
.report-logo{border-radius:10px;background:#174a6e;border:0;color:#fff;width:58px;height:58px;font-size:25px}
.report-brand h2{color:#173f5b;font-size:25px;letter-spacing:.7px}
.report-brand p{color:#647789;font-size:11px}
.report-meta{background:#f5f8fb;border:1px solid #dce5ed;border-radius:5px;padding:10px 13px;color:#334e68;min-width:205px}
.report-title{padding:22px 0 17px}
.report-title h3{color:#173f5b;font-size:21px;letter-spacing:.35px;line-height:1.45}
.report-title p{font-size:12px;color:#647789}
.report-summary{gap:12px;margin:10px 0 22px}
.report-metric{border:1px solid #d9e3eb;border-top:3px solid #28739a;border-radius:5px;background:#fff;padding:14px 15px}
.report-metric span{font-size:9px;letter-spacing:.65px;color:#647789}
.report-metric b{color:#173f5b;font-size:22px}
.report-section-title{background:#174a6e;border-radius:3px 3px 0 0;padding:11px 13px;letter-spacing:.35px;font-size:11px}
.report-table{font-size:10.5px;color:#273746}
.report-table th{background:#eaf0f5;color:#173f5b;font-size:9px;text-transform:uppercase;letter-spacing:.4px}
.report-table th,.report-table td{padding:9px 10px;border:1px solid #d7e0e8}
.report-table tbody tr:nth-child(even){background:#f7f9fb}
.report-table tbody tr:hover{background:#eef6fb}
.report-bottom{gap:14px;margin-top:18px}
.report-chart-box,.report-info-box{border:1px solid #d7e0e8;border-radius:5px;padding:15px;background:#fff}
.report-chart-box h4,.report-info-box h4{font-size:11px;color:#173f5b;border-bottom:1px solid #e1e8ee;padding-bottom:9px;letter-spacing:.3px}
.report-info-box p{font-size:10.5px;color:#42576a;line-height:1.55}
.report-sign{color:#334e68}
.report-sign-line{border-color:#9aabb9}
.report-footer{border-top:1px solid #cbd7e1;color:#647789;font-size:9px;padding-top:13px}
.report-toolbar{background:#f7f9fb;border:1px solid #dce5ed;border-radius:7px;padding:14px}
@media(max-width:800px){.report-paper{padding:15px}.report-meta{min-width:0;width:100%}.report-title h3{font-size:17px}.report-table{min-width:650px}}
@media print{
  body{background:#fff!important;color:#111!important}
  .report-paper{padding:0!important;border:0!important;box-shadow:none!important}
  .report-head{border-bottom:3px solid #174a6e!important}
  .report-summary{gap:7px!important}
  .report-metric,.report-info-box{break-inside:avoid;border-color:#cbd5df!important}
  .report-table thead{display:table-header-group}
  .report-table tr{break-inside:avoid}
  .report-table th,.report-section-title{background:#eaf0f5!important;color:#173f5b!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .report-paper:before{position:fixed;top:42%;left:12%}
  .report-sign{break-inside:avoid}
}
</style>
<section class="panel report-toolbar"><form method="get" class="report-toolbar"><div class="field"><label>Dari tanggal</label><input type="date" name="from" value="<?=e($from)?>" required></div><div class="field"><label>Sampai tanggal</label><input type="date" name="to" value="<?=e($to)?>" required></div><button class="btn primary"><i class="fa-solid fa-filter"></i> Terapkan Filter</button></form><button type="button" class="btn light" onclick="window.print()"><i class="fa-solid fa-file-pdf"></i> Unduh PDF</button></section>
<section class="report-paper">
<header class="report-head"><div class="report-brand"><div class="report-logo"><i class="fa-solid fa-leaf"></i></div><div><h2><?=e(setting($pdo,'nama_sistem','RAM SAWIT'))?></h2><p>Sistem Informasi Harga Tandan Buah Segar (TBS)</p><p>Transparan · Akurat · Untuk Petani</p></div></div><div class="report-meta"><b>Hari / Tanggal:</b> <?=e($printDate)?><br><b>Waktu Cetak:</b> <span class="live-print-time">—</span><br><b>Nomor Laporan:</b> <?=e($reportNo)?></div></header>
<div class="report-title"><h3>LAPORAN REKAPITULASI<br>HARGA TANDAN BUAH SEGAR (TBS) KELAPA SAWIT</h3><p>Periode <?=e(date('d-m-Y',strtotime($from)))?> s/d <?=e(date('d-m-Y',strtotime($to)))?></p></div>
<div class="report-summary"><div class="report-metric"><span><i class="fa-regular fa-file-lines"></i> Total catatan harga</span><b><?=number_format($total,0,',','.')?></b></div><div class="report-metric"><span><i class="fa-solid fa-city"></i> Jumlah desa</span><b><?=number_format($desaCount,0,',','.')?></b></div><div class="report-metric"><span><i class="fa-solid fa-warehouse"></i> Jumlah RAM</span><b><?=number_format($ramCount,0,',','.')?></b></div><div class="report-metric"><span><i class="fa-solid fa-chart-line"></i> Rata-rata harga</span><b><?=e(rupiah($avg))?><small style="font-size:11px"> /kg</small></b></div></div>
<div class="report-section-title">RINCIAN HARGA TBS PER TANGGAL, DESA DAN RAM</div><div style="overflow-x:auto"><table class="report-table"><thead><tr><th>No.</th><th>Tanggal</th><th>Desa</th><th>Nama RAM</th><th>Harga (Rp/Kg)</th><th>Keterangan</th></tr></thead><tbody><?php foreach($rows as $i=>$r):?><tr><td><?=($i+1)?></td><td><?=e(date('d-m-Y',strtotime($r['tanggal'])))?></td><td><?=e($r['desa'])?></td><td><?=e($r['ram']??'Belum ditautkan')?></td><td><?=e(number_format((float)$r['harga_per_kg'],0,',','.'))?></td><td><?=e($r['catatan']?:'—')?></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="6" class="report-empty">Belum ada catatan harga pada periode ini.</td></tr><?php endif;?></tbody></table></div>
<div class="report-bottom"><div class="report-info-box"><h4><i class="fa-solid fa-circle-info"></i> INFORMASI LAPORAN</h4><p><b>Tanggal Cetak:</b> <?=e($printDate)?></p><p><b>Waktu Cetak:</b> <span class="live-print-time">—</span></p><p><b>Periode Laporan:</b> <?=e(date('d-m-Y',strtotime($from)))?> s/d <?=e(date('d-m-Y',strtotime($to)))?></p><p><b>Dibuat oleh:</b> <?=e($_SESSION['user']['nama']??'Administrator')?></p><p><b>Sumber Data:</b> Database RAM Sawit</p><div class="report-sign">Mengetahui,<br><b>Administrator</b><div class="report-sign-line"></div><small>Nama / tanda tangan</small></div></div></div>
<footer class="report-footer"><span>“Bersama Membangun Transparansi Harga TBS untuk Kesejahteraan Petani Sawit.”</span><span><b>RAM SAWIT</b><br><?=e(setting($pdo,'nama_pengelola','Rumpun Abdi Mandiri'))?></span></footer>
</section>
<script>
(function(){
  function updatePrintTimes(){
    const now = new Date();
    const time = new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false,timeZone:'Asia/Jakarta'}).format(now) + ' WIB';
    document.querySelectorAll('.live-print-time').forEach(el=>el.textContent=time);
  }
  updatePrintTimes();
  window.addEventListener('beforeprint', updatePrintTimes);
  document.querySelectorAll('.report-toolbar button[onclick="window.print()"]')?.forEach(btn=>btn.addEventListener('click',updatePrintTimes));
})();
</script>
<?php include __DIR__.'/../includes/layout_end.php'; ?>
