<?php
require __DIR__.'/../config/database.php';require_admin();
if(isset($_GET['download']) && $_GET['download']==='sql'){
  log_activity($pdo,'Mengunduh backup database SQL');
  $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_NUM);$out="-- Backup RAM Sawit\n-- Dibuat: ".date('Y-m-d H:i:s')."\nSET FOREIGN_KEY_CHECKS=0;\n";
  foreach($tables as $t){$table=$t[0];$safe='`'.str_replace('`','``',$table).'`';$create=$pdo->query("SHOW CREATE TABLE $safe")->fetch(PDO::FETCH_NUM);$out.="\nDROP TABLE IF EXISTS $safe;\n".$create[1].";\n";$rows=$pdo->query("SELECT * FROM $safe")->fetchAll(PDO::FETCH_ASSOC);foreach($rows as $row){$cols=array_map(fn($c)=>'`'.str_replace('`','``',$c).'`',array_keys($row));$vals=array_map(fn($v)=>$v===null?'NULL':$pdo->quote((string)$v),array_values($row));$out.='INSERT INTO '.$safe.' ('.implode(',',$cols).') VALUES ('.implode(',',$vals).");\n";}}
  $out.="SET FOREIGN_KEY_CHECKS=1;\n";header('Content-Type: application/sql; charset=utf-8');header('Content-Disposition: attachment; filename=ram-sawit-backup-'.date('Ymd-His').'.sql');header('X-Content-Type-Options: nosniff');echo $out;exit;
}
$title='Backup Database';$subtitle='Simpan salinan database sebelum pembaruan sistem';include __DIR__.'/../includes/layout.php';?>
<section class="panel"><div class="panel-head"><h3><i class="fa-solid fa-database"></i> Backup MySQL</h3></div><p>Unduh salinan tabel dan data dari database yang sedang terhubung. Simpan file backup di lokasi aman dan jangan menaruhnya di folder publik web.</p><div class="alert" style="margin:16px 0">Lakukan backup sebelum mengganti file web, mengubah struktur database, atau menghapus data. File SQL berisi data sensitif termasuk akun pengguna; jangan bagikan secara terbuka.</div><a class="btn primary" href="?download=sql"><i class="fa-solid fa-download"></i> Unduh Backup SQL</a></section><?php include __DIR__.'/../includes/layout_end.php';?>
