<?php
require __DIR__.'/../config/database.php'; require_admin();
$title='Pengaturan'; $subtitle='Kendali sistem, navigasi, dan pengelolaan fitur'; $msg='';
if (empty($_SESSION['csrf_fitur'])) $_SESSION['csrf_fitur']=bin2hex(random_bytes(32));
$csrf=$_SESSION['csrf_fitur'];
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!hash_equals($csrf,(string)($_POST['csrf']??''))) { http_response_code(403); exit('Permintaan tidak valid. Muat ulang halaman dan coba lagi.'); }
  $action=$_POST['action']??'';
  if ($action==='save_settings') {
    $q=$pdo->prepare('INSERT INTO pengaturan(nama,nilai) VALUES(?,?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)');
    foreach(['nama_sistem','nama_pengelola','kecamatan','deskripsi'] as $k) $q->execute([$k,trim($_POST[$k]??'')]);
    log_activity($pdo,'Memperbarui identitas sistem'); $_SESSION['flash']='Identitas sistem berhasil disimpan.';
  } elseif ($action==='save_colors') {
    $hexKeys=['warna_utama','warna_aksen','warna_latar']; $valid=true; $colors=[];
    foreach($hexKeys as $key){ $value=strtoupper(trim($_POST[$key]??'')); if(!preg_match('/^#[0-9A-F]{6}$/',$value)){ $valid=false; break; } $colors[$key]=$value; }
    if(!$valid){ $_SESSION['flash']='Warna tidak valid. Pilih warna melalui pemilih warna.'; }
    else { $q=$pdo->prepare('INSERT INTO pengaturan(nama,nilai) VALUES(?,?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)'); foreach($colors as $k=>$v) $q->execute([$k,$v]); log_activity($pdo,'Mengubah tema warna website'); $_SESSION['flash']='Tema warna berhasil disimpan dan diterapkan di seluruh halaman.'; }
  } elseif ($action==='add_feature') {
    $name=trim($_POST['nama_fitur']??''); $path=trim(str_replace('\\','/',$_POST['path_fitur']??''));
    $icon=trim($_POST['ikon_fitur']??'fa-puzzle-piece'); $role=$_POST['role_fitur']??'both'; $order=(int)($_POST['urutan_fitur']??100);
    if ($name==='' || strlen($name)>100 || !preg_match('~^(?!/)(?!.*\.\.)[A-Za-z0-9_/-]+\.php$~',$path) || !preg_match('/^fa-[a-z0-9-]+$/',$icon) || !in_array($role,['admin','user','both'],true)) {
      $_SESSION['flash']='Data fitur tidak valid. Gunakan path relatif seperti modul/fitur.php dan ikon Font Awesome, misalnya fa-chart-line.';
    } else {
      $check=$pdo->prepare('SELECT COUNT(*) FROM fitur_web WHERE path=?'); $check->execute([$path]);
      if ($check->fetchColumn()) $_SESSION['flash']='Path fitur tersebut sudah terdaftar.';
      else { $q=$pdo->prepare('INSERT INTO fitur_web(nama,path,ikon,role,aktif,bawaan,urutan) VALUES(?,?,?,?,0,0,?)'); $q->execute([$name,$path,$icon,$role,$order]); log_activity($pdo,'Mendaftarkan fitur: '.$name); $_SESSION['flash']='Fitur ditambahkan dalam keadaan nonaktif. Aktifkan setelah file PHP fitur tersedia.'; }
    }
  } elseif ($action==='toggle_feature') {
    $id=(int)($_POST['id']??0); $q=$pdo->prepare('SELECT nama,path,aktif FROM fitur_web WHERE id=?'); $q->execute([$id]); $feature=$q->fetch();
    if ($feature) {
      $new=(int)!((int)$feature['aktif']);
      $target=__DIR__.'/../'.ltrim($feature['path'],'/');
      if ($new && (!is_file($target) || str_contains($feature['path'],'..'))) $_SESSION['flash']='Fitur belum dapat diaktifkan karena file PHP belum tersedia atau path tidak aman.';
      else { $u=$pdo->prepare('UPDATE fitur_web SET aktif=? WHERE id=?'); $u->execute([$new,$id]); log_activity($pdo,($new?'Mengaktifkan':'Menonaktifkan').' fitur: '.$feature['nama']); $_SESSION['flash']='Status fitur berhasil diperbarui.'; }
    }
  } elseif ($action==='delete_feature') {
    $id=(int)($_POST['id']??0); $q=$pdo->prepare('SELECT nama FROM fitur_web WHERE id=?'); $q->execute([$id]); $name=$q->fetchColumn();
    if ($name!==false) { $d=$pdo->prepare('DELETE FROM fitur_web WHERE id=?'); $d->execute([$id]); log_activity($pdo,'Menghapus tautan fitur: '.$name); $_SESSION['flash']='Fitur dihapus dari navigasi. File program dan data database tidak ikut dihapus.'; }
  }
  header('Location: pengaturan.php'); exit;
}
include __DIR__.'/../includes/layout.php';
if (!empty($_SESSION['flash'])) { echo '<div class="alert success">'.e($_SESSION['flash']).'</div>'; unset($_SESSION['flash']); }
?>
<section class="form-panel"><div class="panel-head"><h3><i class="fa-solid fa-sliders"></i> Identitas Sistem</h3></div>
<form method="post"><input type="hidden" name="csrf" value="<?=e($csrf)?>"><input type="hidden" name="action" value="save_settings">
<div class="field"><label>Nama sistem</label><input name="nama_sistem" value="<?=e(setting($pdo,'nama_sistem','RAM Sawit'))?>" required></div>
<div class="form-grid"><div class="field"><label>Nama pengelola</label><input name="nama_pengelola" value="<?=e(setting($pdo,'nama_pengelola','Rumpun Abdi Mandiri'))?>"></div><div class="field"><label>Kecamatan</label><input name="kecamatan" value="<?=e(setting($pdo,'kecamatan','Singkohor'))?>"></div></div>
<div class="field"><label>Deskripsi</label><textarea name="deskripsi" rows="3"><?=e(setting($pdo,'deskripsi','Sistem informasi harga TBS sawit'))?></textarea></div><button class="btn primary"><i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan</button></form></section>
<section class="form-panel" style="margin-top:22px"><div class="panel-head"><div><h3><i class="fa-solid fa-palette"></i> Kustomisasi Warna Website</h3><p class="muted">Atur warna utama, aksen, dan latar. Tema tersimpan di database dan digunakan di halaman admin, warga, login, serta beranda.</p></div></div>
<form method="post" id="themeForm"><input type="hidden" name="csrf" value="<?=e($csrf)?>"><input type="hidden" name="action" value="save_colors">
<div class="theme-presets" style="display:flex;gap:9px;flex-wrap:wrap;margin-bottom:18px"><button type="button" class="btn light" data-preset="#164E78|#38BDF8|#F3F9FD">Biru Profesional</button><button type="button" class="btn light" data-preset="#176B3A|#8BC34A|#F5FAF3">Hijau Sawit</button><button type="button" class="btn light" data-preset="#8A4B12|#F4B942|#FFF9EE">Emas Pertanian</button><button type="button" class="btn light" data-preset="#5B3A91|#B49AE8|#F8F5FC">Ungu Modern</button><button type="button" class="btn light" data-preset="#087E8B|#42C6B7|#F1FAF9">Teal Segar</button></div>
<div class="form-grid"><div class="field"><label>Warna utama (menu, sidebar, header)</label><div style="display:flex;gap:10px;align-items:center"><input type="color" name="warna_utama" value="<?=e(setting($pdo,'warna_utama','#164E78'))?>" style="width:64px;height:44px;padding:4px" required><input data-hex="warna_utama" value="<?=e(setting($pdo,'warna_utama','#164E78'))?>" maxlength="7" pattern="#[0-9A-Fa-f]{6}" aria-label="Kode warna utama" required></div></div>
<div class="field"><label>Warna aksen (tombol, ikon, sorotan)</label><div style="display:flex;gap:10px;align-items:center"><input type="color" name="warna_aksen" value="<?=e(setting($pdo,'warna_aksen','#38BDF8'))?>" style="width:64px;height:44px;padding:4px" required><input data-hex="warna_aksen" value="<?=e(setting($pdo,'warna_aksen','#38BDF8'))?>" maxlength="7" pattern="#[0-9A-Fa-f]{6}" aria-label="Kode warna aksen" required></div></div>
<div class="field"><label>Warna latar halaman</label><div style="display:flex;gap:10px;align-items:center"><input type="color" name="warna_latar" value="<?=e(setting($pdo,'warna_latar','#F3F9FD'))?>" style="width:64px;height:44px;padding:4px" required><input data-hex="warna_latar" value="<?=e(setting($pdo,'warna_latar','#F3F9FD'))?>" maxlength="7" pattern="#[0-9A-Fa-f]{6}" aria-label="Kode warna latar" required></div></div></div>
<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:8px 0 18px"><div id="themePreview" style="display:flex;gap:8px;align-items:center;padding:12px 15px;border-radius:12px;border:1px solid var(--line);background:var(--bg)"><span style="width:25px;height:25px;border-radius:7px;background:<?=e(setting($pdo,'warna_utama','#164E78'))?>"></span><span style="width:25px;height:25px;border-radius:7px;background:<?=e(setting($pdo,'warna_aksen','#38BDF8'))?>"></span><span style="width:25px;height:25px;border-radius:7px;background:<?=e(setting($pdo,'warna_latar','#F3F9FD'))?>;border:1px solid #ccc"></span><strong>Pratinjau kombinasi warna</strong></div><small class="muted">Tip: gunakan warna utama gelap dan aksen yang cukup kontras agar teks tetap mudah dibaca.</small></div>
<button class="btn primary"><i class="fa-solid fa-palette"></i> Simpan & Terapkan ke Website</button></form>
<script>(function(){const form=document.getElementById('themeForm');if(!form)return;function sync(input,val){const hex=form.querySelector('[data-hex="'+input.name+'"]');if(hex)hex.value=val.toUpperCase();}form.querySelectorAll('input[type=color]').forEach(input=>input.addEventListener('input',()=>sync(input,input.value)));form.querySelectorAll('[data-hex]').forEach(hex=>hex.addEventListener('input',()=>{if(/^#[0-9a-fA-F]{6}$/.test(hex.value)){const picker=form.querySelector('[name="'+hex.dataset.hex+'"]');if(picker)picker.value=hex.value;}}));form.querySelectorAll('[data-preset]').forEach(btn=>btn.addEventListener('click',()=>{const vals=btn.dataset.preset.split('|');['warna_utama','warna_aksen','warna_latar'].forEach((name,i)=>{const picker=form.querySelector('[name="'+name+'"]');picker.value=vals[i];sync(picker,vals[i]);});}));})();</script></section>
<section class="form-panel" style="margin-top:22px"><div class="panel-head"><div><h3><i class="fa-solid fa-puzzle-piece"></i> Kendali Fitur & Navigasi</h3><p class="muted">Kelola menu yang terlihat oleh admin atau warga tanpa menghapus file program maupun data utama.</p></div></div>
<div class="alert" style="margin:12px 0">Untuk fitur baru: developer membuat file PHP terlebih dahulu, lalu daftarkan path-nya di sini. Fitur baru selalu nonaktif sampai siap diuji. Menghapus fitur hanya menghapus tautannya dari navigasi.</div>
<form method="post" class="feature-add-form"><input type="hidden" name="csrf" value="<?=e($csrf)?>"><input type="hidden" name="action" value="add_feature">
<div class="form-grid"><div class="field"><label>Nama fitur</label><input name="nama_fitur" placeholder="Contoh: Grafik Tren Harga" required maxlength="100"></div><div class="field"><label>Path file PHP relatif</label><input name="path_fitur" placeholder="modul/grafik-tren.php" required pattern="[A-Za-z0-9_/-]+\.php"><small>Contoh: modul/grafik-tren.php</small></div></div>
<div class="form-grid"><div class="field"><label>Ikon Font Awesome</label><input name="ikon_fitur" value="fa-puzzle-piece" pattern="fa-[a-z0-9-]+" required></div><div class="field"><label>Tampilkan untuk</label><select name="role_fitur"><option value="both">Admin dan warga</option><option value="admin">Admin saja</option><option value="user">Warga saja</option></select></div><div class="field"><label>Urutan menu</label><input type="number" name="urutan_fitur" value="100" min="1" max="9999"></div></div>
<button class="btn primary"><i class="fa-solid fa-plus"></i> Daftarkan Fitur</button></form>
<div style="overflow-x:auto;margin-top:22px"><table class="data-table"><thead><tr><th>Fitur</th><th>Path</th><th>Akses</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
<?php $features=$pdo->query('SELECT * FROM fitur_web ORDER BY urutan,id')->fetchAll(); foreach($features as $f): $fileExists=is_file(__DIR__.'/../'.ltrim($f['path'],'/')); ?>
<tr><td><i class="fa-solid <?=e($f['ikon'])?>"></i> <strong><?=e($f['nama'])?></strong><?php if($f['bawaan']): ?><small class="muted"> · fitur bawaan</small><?php endif; ?></td><td><code><?=e($f['path'])?></code><?php if(!$fileExists): ?><small style="display:block;color:#b45309">File belum tersedia</small><?php endif; ?></td><td><?=e(['admin'=>'Admin','user'=>'Warga','both'=>'Admin & Warga'][$f['role']]??$f['role'])?></td><td><span class="status-pill" style="display:inline-block;padding:4px 9px;border-radius:20px;background:<?=((int)$f['aktif']===1?'#dcfce7':'#f1f5f9')?>;color:<?=((int)$f['aktif']===1?'#166534':'#475569')?>"><?=((int)$f['aktif']===1?'Aktif':'Nonaktif')?></span></td><td><div style="display:flex;gap:6px;flex-wrap:wrap">
<form method="post"><input type="hidden" name="csrf" value="<?=e($csrf)?>"><input type="hidden" name="action" value="toggle_feature"><input type="hidden" name="id" value="<?=(int)$f['id']?>"><button class="btn light" <?=(!$fileExists && !(int)$f['aktif'])?'disabled title="File fitur belum tersedia"':''?>><i class="fa-solid fa-power-off"></i> <?=((int)$f['aktif']===1?'Nonaktifkan':'Aktifkan')?></button></form>
<form method="post" onsubmit="return confirm('Hapus tautan fitur ini dari navigasi? File PHP dan data tidak dihapus.');"><input type="hidden" name="csrf" value="<?=e($csrf)?>"><input type="hidden" name="action" value="delete_feature"><input type="hidden" name="id" value="<?=(int)$f['id']?>"><button class="btn light" style="color:#b91c1c"><i class="fa-solid fa-trash"></i> Hapus</button></form>
</div></td></tr><?php endforeach; if(!$features): ?><tr><td colspan="5">Belum ada fitur terdaftar.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php include __DIR__.'/../includes/layout_end.php'; ?>
