<?php
require __DIR__.'/../config/database.php'; require_admin(); require __DIR__.'/../includes/crud.php';
render_crud($pdo,['title'=>'Pengumuman','table'=>'pengumuman','fields'=>['judul'=>['label'=>'Judul','required'=>true],'isi'=>['label'=>'Isi pengumuman','type'=>'textarea','required'=>true],'tanggal'=>['label'=>'Tanggal','type'=>'date','default'=>date('Y-m-d'),'required'=>true],'aktif'=>['label'=>'Status','options'=>['1'=>'Aktif','0'=>'Nonaktif'],'default'=>'1']],'columns'=>['id'=>'ID','judul'=>'Judul','tanggal'=>'Tanggal','aktif'=>'Aktif']]);
