<?php
require __DIR__.'/../config/database.php'; require_admin(); require __DIR__.'/../includes/crud.php';
// Form pembaruan harga RAM: menyimpan catatan harga baru agar riwayat harga tetap terjaga.
$priceMessage=''; $priceError='';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_ram_price'])) {
    $ramId=(int)($_POST['ram_id']??0); $price=(float)($_POST['harga_per_kg']??0); $date=trim((string)($_POST['tanggal']??date('Y-m-d'))); $note=trim((string)($_POST['catatan_harga']??''));
    try {
        $q=$pdo->prepare('SELECT id,desa_id,nama FROM ram WHERE id=?'); $q->execute([$ramId]); $selectedRam=$q->fetch();
        $dt=DateTime::createFromFormat('Y-m-d',$date);
        if (!$selectedRam || $price<=0 || !$dt || $dt->format('Y-m-d')!==$date) { $priceError='Pilih RAM yang valid, isi harga lebih dari nol, dan gunakan tanggal yang benar.'; }
        else { $ins=$pdo->prepare('INSERT INTO harga_tbs(desa_id,ram_id,tanggal,harga_per_kg,catatan,created_by) VALUES(?,?,?,?,?,?)'); $ins->execute([(int)$selectedRam['desa_id'],$ramId,$date,$price,$note!==''?$note:null,(int)($_SESSION['user']['id']??0) ?: null]); log_activity($pdo,'Memperbarui harga TBS RAM '.$selectedRam['nama'].' menjadi Rp '.number_format($price,0,',','.')); header('Location: '.$_SERVER['PHP_SELF'].'?price_saved=1'); exit; }
    } catch (Throwable $e) { $priceError='Harga gagal disimpan. Periksa struktur database dan data yang dipilih.'; }
}
$ds=$pdo->query('SELECT id,nama FROM desa ORDER BY nama')->fetchAll();$opts=[];foreach($ds as $d)$opts[$d['id']]=$d['nama'];
render_crud($pdo,['title'=>'Data RAM','table'=>'ram','fields'=>['nama'=>['label'=>'Nama RAM','required'=>true],'desa_id'=>['label'=>'Desa','type'=>'select','options'=>$opts,'required'=>true],'alamat'=>['label'=>'Alamat / patokan'],'kontak'=>['label'=>'Nomor kontak'],'status'=>['label'=>'Status','options'=>['Aktif'=>'Aktif','Nonaktif'=>'Nonaktif'],'default'=>'Aktif']],'columns'=>['id'=>'ID','nama'=>'Nama RAM','desa_id'=>'Desa','alamat'=>'Alamat','kontak'=>'Kontak','status'=>'Status'],'after_render'=>function() use ($pdo,$priceError) {
    if (isset($_GET['price_saved'])) echo '<div class="alert success">Harga RAM berhasil diperbarui. Riwayat harga sebelumnya tetap tersimpan.</div>';
    if ($priceError!=='') echo '<div class="alert error">'.e($priceError).'</div>';
    $ramsForPrice=$pdo->query("SELECT r.id,r.nama,d.nama desa FROM ram r JOIN desa d ON d.id=r.desa_id ORDER BY d.nama,r.nama")->fetchAll();
    $latestRamPrices=$pdo->query("SELECT r.nama ram,d.nama desa,h.harga_per_kg,h.tanggal FROM harga_tbs h JOIN ram r ON r.id=h.ram_id JOIN desa d ON d.id=h.desa_id WHERE h.id=(SELECT h2.id FROM harga_tbs h2 WHERE h2.ram_id=h.ram_id ORDER BY h2.tanggal DESC,h2.id DESC LIMIT 1) ORDER BY d.nama,r.nama")->fetchAll();
    echo '<section class="form-panel" style="margin-bottom:20px"><div class="panel-head"><h3><i class="fa-solid fa-tags"></i> Perbarui Harga TBS per RAM</h3></div><p class="muted small">Harga baru disimpan sebagai riwayat agar catatan sebelumnya tidak hilang.</p><form method="post"><div class="form-grid"><div class="field"><label>RAM dan Desa</label><select name="ram_id" required><option value="">-- Pilih RAM --</option>';
    foreach($ramsForPrice as $r) echo '<option value="'.(int)$r['id'].'">'.e($r['nama'].' — '.$r['desa']).'</option>';
    echo '</select></div><div class="field"><label>Tanggal harga</label><input type="date" name="tanggal" value="'.e(date('Y-m-d')).'" required></div><div class="field"><label>Harga per Kg (Rp)</label><input type="number" name="harga_per_kg" min="1" step="1" placeholder="Contoh: 2850" required></div><div class="field"><label>Catatan (opsional)</label><input name="catatan_harga" placeholder="Misalnya harga periode minggu ini"></div></div><button class="btn primary" type="submit" name="save_ram_price" value="1"><i class="fa-solid fa-floppy-disk"></i> Simpan Harga Baru</button></form></section>';
    echo '<section class="panel"><div class="panel-head"><div><h3>Harga Terbaru per RAM</h3><p class="muted small">Berdasarkan catatan harga terbaru di MySQL</p></div></div><div class="table-wrap"><table><thead><tr><th>Desa</th><th>Nama RAM</th><th>Harga / Kg</th><th>Tanggal</th></tr></thead><tbody>';
    foreach($latestRamPrices as $rp) echo '<tr><td>'.e($rp['desa']).'</td><td>'.e($rp['ram']).'</td><td><strong>'.rupiah($rp['harga_per_kg']).'</strong></td><td>'.e(date('d-m-Y',strtotime($rp['tanggal']))).'</td></tr>';
    if(!$latestRamPrices) echo '<tr><td colspan="4" class="empty">Belum ada harga yang terhubung langsung ke RAM. Tambahkan harga melalui formulir di atas.</td></tr>'; echo '</tbody></table></div></section>';
}]);
