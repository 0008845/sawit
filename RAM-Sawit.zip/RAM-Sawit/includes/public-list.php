<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_login();

function public_list(PDO $pdo, string $kind, string $pageTitle, string $table, string $where = '1=1'): void
{
    // Nama tabel dan kolom dipetakan eksplisit sesuai database ram_sawit.
    $allowed = [
        'news' => ['table' => 'berita', 'content' => 'ringkasan', 'status' => "status = 'Terbit'"],
        'announce' => ['table' => 'pengumuman', 'content' => 'isi', 'status' => 'aktif = 1'],
    ];
    if (!isset($allowed[$kind])) { http_response_code(400); echo 'Jenis informasi tidak dikenal.'; return; }
    $cfg = $allowed[$kind];
    $sql = "SELECT id, judul, {$cfg['content']} AS konten, tanggal FROM `{$cfg['table']}` WHERE {$cfg['status']} ORDER BY tanggal DESC, id DESC";
    $rows = $pdo->query($sql)->fetchAll();
    include __DIR__ . '/layout.php';
    ?>
    <section class="panel public-panel animate-in">
      <div class="panel-head"><div><h3><i class="fa-solid <?= $kind === 'news' ? 'fa-newspaper' : 'fa-bullhorn' ?> panel-title-icon"></i> <?= e($pageTitle) ?></h3><p class="muted small">Informasi terbaru yang dipublikasikan oleh pengelola RAM Sawit.</p></div>
      <label class="public-search-wrap"><i class="fa-solid fa-magnifying-glass"></i><input class="search" data-card-filter="public-items" placeholder="Cari informasi..." aria-label="Cari informasi"></label></div>
      <?php if ($rows): ?><div class="public-items" id="public-items">
        <?php foreach ($rows as $index => $row): ?><article class="info-card animate-in" style="--delay: <?= min($index, 8) * 60 ?>ms">
          <div class="info-card-date"><i class="fa-regular fa-calendar"></i> <?= e(date('d M Y', strtotime($row['tanggal']))) ?></div>
          <h3><?= e($row['judul']) ?></h3><p><?= nl2br(e($row['konten'])) ?></p>
        </article><?php endforeach; ?>
      </div><p class="empty" data-no-results hidden>Tidak ada informasi yang cocok dengan pencarian.</p>
      <?php else: ?><div class="empty-state"><span class="empty-state-icon"><i class="fa-regular fa-folder-open"></i></span><h3>Belum ada <?= $kind === 'news' ? 'berita' : 'pengumuman' ?> yang tersedia</h3><p>Informasi akan tampil di sini setelah diterbitkan oleh administrator.</p></div><?php endif; ?>
    </section>
    <?php include __DIR__ . '/layout_end.php';
}
