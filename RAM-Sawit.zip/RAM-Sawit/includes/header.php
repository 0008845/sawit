<?php
require_once __DIR__.'/../config/database.php'; require_login();
$page=basename($_SERVER['PHP_SELF']); $isWarga=($_SESSION['user']['role']??'')==='user';
$siteName=setting($pdo,'nama_sistem','RAM Sawit');
$role=$isWarga?'user':'admin';
$qMenu=$pdo->prepare("SELECT nama,path,ikon FROM fitur_web WHERE aktif=1 AND (role=? OR role='both') ORDER BY urutan,id");
$qMenu->execute([$role]);
$menu=array_map(static fn($row)=>[$row['path'],$row['ikon'],$row['nama']],$qMenu->fetchAll());
// Jangan tampilkan tautan yang belum memiliki file implementasi; fitur dapat didaftarkan dahulu lalu diaktifkan setelah siap.
$menu=array_values(array_filter($menu,static function($m){
 $path=ltrim((string)$m[0],'/');
 return !str_contains($path,'..') && is_file(__DIR__.'/../'.$path);
}));
$title=$title??'Dashboard';
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" type="image/png" sizes="128x128" href="/RAM-Sawit/assets/images/agroinfo-favicon.png?v=1"><link rel="shortcut icon" href="/RAM-Sawit/assets/images/agroinfo-favicon.ico?v=1"><title><?=e($title)?> · <?=e($siteName)?></title><link rel="stylesheet" href="/RAM-Sawit/assets/css/style.css?v=20261025-theme-custom"><style>:root{--theme-primary:<?=e(setting($pdo,'warna_utama','#164E78'))?>;--theme-accent:<?=e(setting($pdo,'warna_aksen','#38BDF8'))?>;--theme-bg:<?=e(setting($pdo,'warna_latar','#F3F9FD'))?>;--red:var(--theme-accent);--amber:var(--theme-accent);--forest:var(--theme-primary);--bg:var(--theme-bg);--blue:var(--theme-accent);--blue-deep:var(--theme-primary)}.sidebar{background:linear-gradient(155deg,color-mix(in srgb,var(--theme-primary),#071b2b 28%),var(--theme-primary) 58%,color-mix(in srgb,var(--theme-primary),#fff 10%))}.brand-icon,.avatar{background:color-mix(in srgb,var(--theme-accent),transparent 78%);color:var(--theme-accent)}.nav-link.active,.btn.primary,.stat .icon{background:var(--theme-accent);color:#fff}.hero,.village-intro{background:linear-gradient(120deg,var(--theme-primary),color-mix(in srgb,var(--theme-primary),var(--theme-accent) 45%),var(--theme-accent))}.village-number,.village-card-head h3,.head>i{color:var(--theme-primary)}.content{background:var(--theme-bg)}</style><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"><script src="https://cdn.jsdelivr.net/npm/chart.js"></script></head><body><div class="app-shell">
