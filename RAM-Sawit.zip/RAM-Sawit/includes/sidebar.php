<aside class="sidebar" id="sidebar">
  <a class="brand" href="/RAM-Sawit/dashboard.php">
    <span class="brand-icon"><i class="fa-solid fa-leaf"></i></span>
    <span class="brand-copy"><b>RAM SAWIT</b><small>Singkohor · Aceh Singkil</small></span>
  </a>
  <div class="side-caption">NAVIGASI UTAMA</div>
  <nav aria-label="Navigasi utama">
    <?php foreach($menu as $m): $href='/RAM-Sawit/'.$m[0]; $active=($_SERVER['PHP_SELF']===$href || ($m[0]==='dashboard.php' && basename($_SERVER['PHP_SELF'])==='dashboard.php')); ?>
      <a class="nav-link <?=$active?'active':''?>" href="<?=e($href)?>" title="<?=e($m[2])?>">
        <span class="nav-icon"><i class="fa-solid <?=e($m[1])?>"></i></span><span class="nav-label"><?=e($m[2])?></span>
      </a>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-bottom">
    <div class="sidebar-note"><i class="fa-solid fa-seedling"></i><span><b>Info TBS Terpadu</b><small>Data harga dan panen</small></span></div>
    <div class="sidebar-user">
      <div class="avatar"><i class="fa-solid fa-user<?=is_admin()?'-shield':''?>"></i></div>
      <div class="sidebar-user-copy"><b><?=e($_SESSION['user']['nama'])?></b><small><?=is_admin()?'Administrator':'Warga / Petani'?></small></div>
      <a class="power" href="/RAM-Sawit/logout.php" title="Keluar"><i class="fa-solid fa-power-off"></i></a>
    </div>
  </div>
</aside>