<?php
// Konfigurasi CRUD per modul; seluruh query memakai prepared statements.
function render_crud(PDO $pdo, array $cfg): void {
    $title=$cfg['title']; $subtitle=$cfg['subtitle']??'Kelola data sistem'; $table=$cfg['table']; $fields=$cfg['fields']; $columns=$cfg['columns'];
    $message=''; $error='';
    if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_record'])) {
        $id=(int)($_POST['id']??0); $vals=[];
        foreach($fields as $key=>$f) { $v=trim((string)($_POST[$key]??'')); if(($f['required']??false) && $v==='') {$error='Kolom '.$f['label'].' wajib diisi.'; break;} $vals[$key]=$v===''?null:$v; }
        if(!$error) {
            try {
                if($id>0) { $sets=implode(',',array_map(fn($k)=>"`$k`=?",array_keys($vals))); $sql="UPDATE `$table` SET $sets WHERE id=?"; $pdo->prepare($sql)->execute([...array_values($vals),$id]); log_activity($pdo,"Memperbarui data $title (ID $id)"); }
                else { $ks=array_keys($vals); $sql="INSERT INTO `$table` (`".implode('`,`',$ks)."`) VALUES (".implode(',',array_fill(0,count($ks),'?')).")"; $pdo->prepare($sql)->execute(array_values($vals)); log_activity($pdo,"Menambah data $title"); }
                header('Location: '.$_SERVER['PHP_SELF'].'?saved=1'); exit;
            } catch(Throwable $e) { $error='Data gagal disimpan. Periksa isian dan pastikan tidak ada data duplikat.'; }
        }
    }
    if(isset($_GET['delete']) && ctype_digit((string)$_GET['delete'])) {
        $id=(int)$_GET['delete']; try{$pdo->prepare("DELETE FROM `$table` WHERE id=?")->execute([$id]); log_activity($pdo,"Menghapus data $title (ID $id)"); header('Location: '.$_SERVER['PHP_SELF'].'?deleted=1');exit;}catch(Throwable $e){$error='Data tidak dapat dihapus karena masih digunakan oleh data lain.';}
    }
    $edit=null;
    if(isset($_GET['edit']) && ctype_digit((string)$_GET['edit'])) { $q=$pdo->prepare("SELECT * FROM `$table` WHERE id=?");$q->execute([(int)$_GET['edit']]);$edit=$q->fetch()?:null; }
    $rows=$pdo->query("SELECT * FROM `$table` ORDER BY id DESC")->fetchAll();
    include __DIR__.'/layout.php';
    if(isset($_GET['saved'])) echo '<div class="alert success">Data berhasil disimpan.</div>';
    if(isset($_GET['deleted'])) echo '<div class="alert success">Data berhasil dihapus.</div>';
    if($error) echo '<div class="alert error">'.e($error).'</div>';
    if($cfg['can_add']??true) {
        echo '<section class="form-panel" style="margin-bottom:20px"><div class="panel-head"><h3>'.($edit?'Ubah':'Tambah').' '.$title.'</h3>'.($edit?'<a class="btn light" href="'.e($_SERVER['PHP_SELF']).'">Batal</a>':'').'</div>';
        echo '<form method="post"><input type="hidden" name="id" value="'.e($edit['id']??'').'"><div class="form-grid">';
        foreach($fields as $key=>$f) {
            $value=$edit[$key]??($f['default']??''); echo '<div class="field"><label>'.e($f['label']).'</label>';
            if(isset($f['options'])) { echo '<select name="'.e($key).'" '.(!empty($f['required'])?'required':'').'><option value="">-- Pilih --</option>'; foreach($f['options'] as $v=>$label) echo '<option value="'.e($v).'" '.((string)$value===(string)$v?'selected':'').'>'.e($label).'</option>'; echo '</select>'; }
            elseif(($f['type']??'text')==='textarea') echo '<textarea name="'.e($key).'" rows="3" '.(!empty($f['required'])?'required':'').'>'.e($value).'</textarea>';
            else echo '<input name="'.e($key).'" type="'.e($f['type']??'text').'" value="'.e($value).'" '.(!empty($f['required'])?'required':'').' '.(isset($f['step'])?'step="'.e($f['step']).'"':'').' '.(isset($f['min'])?'min="'.e($f['min']).'"':'').'>';
            echo '</div>';
        }
        echo '</div><button class="btn primary" name="save_record" value="1"><i class="fa-solid fa-floppy-disk"></i> Simpan Data</button></form></section>';
    }
    echo '<section class="panel"><div class="panel-head"><div><h3>Daftar '.$title.'</h3><p class="muted small">Data yang tersimpan di database MySQL</p></div><input class="search" data-filter="#records" placeholder="Cari data..."></div><div class="table-wrap"><table id="records"><thead><tr>';
    foreach($columns as $key=>$label) echo '<th>'.e($label).'</th>'; echo '<th>Aksi</th></tr></thead><tbody>';
    foreach($rows as $row) { echo '<tr>'; foreach($columns as $key=>$label) { $v=$row[$key]??''; if(str_contains($key,'harga')||str_contains($key,'biaya'))$v=rupiah($v); echo '<td>'.e($v).'</td>'; } echo '<td><div class="actions">';
    if($cfg['can_add']??true) echo '<a class="btn light" href="?edit='.(int)$row['id'].'"><i class="fa-solid fa-pen"></i></a><a class="btn danger" data-confirm="Yakin ingin menghapus data ini?" href="?delete='.(int)$row['id'].'"><i class="fa-solid fa-trash"></i></a>';
    echo '</div></td></tr>'; }
    if(!$rows) echo '<tr><td colspan="'.(count($columns)+1).'" class="empty">Belum ada data.</td></tr>';
    echo '</tbody></table></div></section>';
    if (isset($cfg['after_render']) && is_callable($cfg['after_render'])) { ($cfg['after_render'])(); }
    include __DIR__.'/layout_end.php';
}
