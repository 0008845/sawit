<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) session_start();
$DB_HOST = 'localhost'; $DB_NAME = 'ram_sawit'; $DB_USER = 'root'; $DB_PASS = '';
try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database belum siap. Import database/ram_sawit.sql melalui phpMyAdmin dan periksa config/database.php.');
}
// Registry fitur navigasi: admin dapat mengaktifkan, menonaktifkan, menambah, atau menghapus tautan fitur.
$pdo->exec("CREATE TABLE IF NOT EXISTS fitur_web (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL, path VARCHAR(190) NOT NULL UNIQUE, ikon VARCHAR(80) NOT NULL DEFAULT 'fa-puzzle-piece', role ENUM('admin','user','both') NOT NULL DEFAULT 'both', aktif TINYINT(1) NOT NULL DEFAULT 1, bawaan TINYINT(1) NOT NULL DEFAULT 0, urutan INT NOT NULL DEFAULT 100, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$defaultFeatures = [
 ['Dashboard','dashboard.php','fa-chart-pie','both',1],
 ['Harga TBS','admin/harga-tbs.php','fa-tags','admin',2],
 ['Data Desa','admin/data-desa.php','fa-city','admin',3],
 ['Data RAM','admin/data-ram.php','fa-warehouse','admin',4],
 ['Pengumuman','admin/pengumuman.php','fa-bullhorn','admin',5],
 ['Berita','admin/berita.php','fa-newspaper','admin',6],
 ['Laporan','admin/laporan.php','fa-file-lines','admin',7],
 ['Pengguna','admin/pengguna.php','fa-users','admin',8],
 ['Pengaturan','admin/pengaturan.php','fa-gear','admin',9],
 ['Log Aktivitas','admin/aktivitas.php','fa-clock-rotate-left','admin',10],
 ['Backup Database','admin/backup.php','fa-database','admin',11],
 ['Harga TBS','warga/harga-tbs.php','fa-tags','user',10],
 ['Database Desa & RAM','warga/desa.php','fa-map-location-dot','user',11],
 ['Kalkulator Panen','warga/kalkulator.php','fa-calculator','user',12],
 ['Pengumuman','warga/pengumuman.php','fa-bullhorn','user',13],
 ['Berita','warga/berita.php','fa-newspaper','user',14],
];
$seedFeature = $pdo->prepare('INSERT IGNORE INTO fitur_web(nama,path,ikon,role,aktif,bawaan,urutan) VALUES(?,?,?,?,1,1,?)');
foreach ($defaultFeatures as $f) $seedFeature->execute($f);
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function rupiah($value): string { return 'Rp ' . number_format((float)$value, 0, ',', '.'); }
function logged_in(): bool { return !empty($_SESSION['user']); }
function is_admin(): bool { return logged_in() && ($_SESSION['user']['role'] ?? '') === 'admin'; }
function require_login(): void { if (!logged_in()) { header('Location: /RAM-Sawit/login.php'); exit; } }
function require_admin(): void { require_login(); if (!is_admin()) { http_response_code(403); exit('Akses ditolak. Halaman ini khusus administrator.'); } }
function setting(PDO $pdo, string $key, string $default=''): string {
    $q=$pdo->prepare('SELECT nilai FROM pengaturan WHERE nama=?'); $q->execute([$key]); $v=$q->fetchColumn();
    return $v === false ? $default : (string)$v;
}
function log_activity(PDO $pdo, string $activity): void {
    if (!empty($_SESSION['user']['id'])) {
        $q=$pdo->prepare('INSERT INTO log_aktivitas(user_id, aktivitas, ip_address) VALUES(?,?,?)');
        $q->execute([$_SESSION['user']['id'], $activity, $_SERVER['REMOTE_ADDR'] ?? '']);
    }
}
