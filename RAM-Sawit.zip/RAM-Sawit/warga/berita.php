<?php
require_once __DIR__ . '/../config/database.php';
require_login();
$title = 'Berita';
$subtitle = 'Kabar dan informasi seputar kegiatan RAM Sawit';
require_once __DIR__ . '/../includes/public-list.php';
public_list($pdo, 'news', 'Berita Terbaru', 'berita');
