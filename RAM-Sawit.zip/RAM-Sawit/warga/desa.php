<?php
require __DIR__.'/../config/database.php';
require_login();
$title='Database Desa & RAM';
$subtitle='Direktori enam desa dan RAM kelapa sawit di Kecamatan Singkohor';
$sql="SELECT d.id,d.nama AS desa,d.kecamatan,d.alamat AS alamat_desa,d.status AS status_desa,
       r.id AS ram_id,r.nama AS ram,r.alamat AS alamat_ram,r.kontak,r.status AS status_ram,
       h.harga_per_kg,h.tanggal AS tanggal_harga,h.catatan
       FROM desa d LEFT JOIN ram r ON r.desa_id=d.id
       LEFT JOIN harga_tbs h ON h.id=(SELECT h2.id FROM harga_tbs h2 WHERE h2.desa_id=d.id AND (h2.ram_id=r.id OR (h2.ram_id IS NULL AND r.id IS NULL)) ORDER BY h2.tanggal DESC,h2.id DESC LIMIT 1)
       ORDER BY d.nama,r.nama";
$rows=$pdo->query($sql)->fetchAll();
$villages=[];
foreach($rows as $row){$id=(int)$row['id'];if(!isset($villages[$id]))$villages[$id]=['nama'=>$row['desa'],'kecamatan'=>$row['kecamatan'],'alamat'=>$row['alamat_desa'],'status'=>$row['status_desa'],'rams'=>[]];if($row['ram_id']!==null)$villages[$id]['rams'][]=$row;}
$totalRam=(int)$pdo->query('SELECT COUNT(*) FROM ram')->fetchColumn();
$activeRam=(int)$pdo->query("SELECT COUNT(*) FROM ram WHERE status='Aktif'")->fetchColumn();
include __DIR__.'/../includes/layout.php';
?>
<style>
.village-intro{padding:24px 26px;border-radius:18px;background:linear-gradient(120deg,#0C2F4D,#0284C7 72%,#38BDF8);color:#fff;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:20px}.village-intro h2{margin:0 0 8px;font-size:23px}.village-intro p{margin:0;color:#E0F2FE;line-height:1.6}.village-intro .big-icon{font-size:54px;color:#7DD3FC}.village-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:20px}.village-stat{background:#fff;border:1px solid #D7EAF5;border-radius:14px;padding:17px;display:flex;gap:12px;align-items:center}.village-stat .ico{width:42px;height:42px;border-radius:12px;background:#F0F9FF;color:#0284C7;display:grid;place-items:center;font-size:18px}.village-stat b{font-size:22px;display:block}.village-stat small{color:#68786d}.village-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.village-card{background:#fff;border:1px solid #D7EAF5;border-radius:16px;overflow:hidden;box-shadow:0 5px 18px #164E7808;min-width:0}.village-card-head{padding:17px 18px;background:linear-gradient(110deg,#F0F9FF,#fff);border-bottom:1px solid #e5ece4;display:flex;justify-content:space-between;gap:12px;align-items:center}.village-card-head h3{margin:0 0 5px;font-size:16px;color:#164E78}.village-card-head small{color:#718076}.village-number{width:40px;height:40px;border-radius:13px;background:#164E78;color:#7DD3FC;display:grid;place-items:center;font-weight:800;flex-shrink:0}.ram-list{padding:10px 16px}.ram-item{padding:14px 2px;border-bottom:1px solid #edf1ec;display:flex;gap:12px;align-items:flex-start}.ram-item:last-child{border-bottom:0}.ram-icon{width:36px;height:36px;border-radius:11px;background:#E0F2FE;color:#926400;display:grid;place-items:center;flex-shrink:0}.ram-info{min-width:0;flex:1}.ram-info b{display:block;color:#273a2e;margin:1px 0 6px}.ram-info p{font-size:11px;color:#738075;margin:4px 0;line-height:1.5;overflow-wrap:anywhere}.ram-price{font-size:14px;font-weight:800;color:#0284C7;margin-top:7px}.ram-empty{padding:20px;color:#7b887e;font-size:12px}.village-tools{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:16px}.village-tools .search{max-width:360px}.status-pill{display:inline-block;font-size:10px;font-weight:800;padding:5px 9px;border-radius:30px;background:#dcfce7;color:#166534}.status-pill.off{background:#f3f4f6;color:#6b7280}@media(max-width:800px){.village-grid{grid-template-columns:1fr}.village-stats{grid-template-columns:1fr}.village-intro{padding:20px}.village-intro .big-icon{display:none}}
</style>
<section class="village-intro"><div><h2><i class="fa-solid fa-map-location-dot"></i> Database Desa & RAM Sawit</h2><p>Direktori desa, tempat penerimaan TBS, kontak, dan harga terbaru yang tersedia di sistem.<br>Gunakan kolom pencarian untuk menemukan desa atau RAM.</p></div><i class="fa-solid fa-tree big-icon"></i></section>
<section class="village-stats"><div class="village-stat"><span class="ico"><i class="fa-solid fa-house"></i></span><div><b><?=count($villages)?></b><small>Desa terdaftar</small></div></div><div class="village-stat"><span class="ico"><i class="fa-solid fa-warehouse"></i></span><div><b><?=$totalRam?></b><small>RAM terdaftar</small></div></div><div class="village-stat"><span class="ico"><i class="fa-solid fa-circle-check"></i></span><div><b><?=$activeRam?></b><small>RAM berstatus aktif</small></div></div></section>
<section class="panel"><div class="village-tools"><div><h3><i class="fa-solid fa-list-check" style="color:#38BDF8"></i> Daftar RAM per Desa</h3><p class="muted small">Data bersumber dari database. Hubungi pengelola untuk melengkapi alamat atau kontak yang belum tersedia.</p></div><input class="search" data-filter=".village-grid" placeholder="Cari nama desa atau RAM..."></div>
<div class="village-grid" id="village-directory">
<?php $n=0; foreach($villages as $v): $n++; ?>
<article class="village-card"><div class="village-card-head"><div><h3><?=e($v['nama'])?></h3><small><i class="fa-solid fa-location-dot"></i> Kecamatan <?=e($v['kecamatan'])?>, Aceh Singkil</small></div><span class="village-number"><?=str_pad((string)$n,2,'0',STR_PAD_LEFT)?></span></div><div class="ram-list">
<?php if(!$v['rams']): ?><div class="ram-empty">Belum ada RAM yang terdaftar untuk desa ini.</div><?php else: foreach($v['rams'] as $r): ?>
<div class="ram-item"><span class="ram-icon"><i class="fa-solid fa-warehouse"></i></span><div class="ram-info"><b><?=e($r['ram'])?></b><span class="status-pill <?=$r['status_ram']==='Aktif'?'':'off'?>"><?=e($r['status_ram'])?></span><p><i class="fa-solid fa-location-dot"></i> <?=e($r['alamat_ram']?:'Alamat belum dilengkapi')?></p><?php if(!empty($r['kontak'])): ?><p><i class="fa-solid fa-phone"></i> <?=e($r['kontak'])?></p><?php endif; ?><?php if($r['harga_per_kg']!==null): ?><div class="ram-price"><?=rupiah($r['harga_per_kg'])?> / kg</div><p>Harga diperbarui: <?=e($r['tanggal_harga'])?></p><?php else: ?><p>Harga TBS belum tersedia.</p><?php endif; ?></div></div>
<?php endforeach; endif; ?></div></article>
<?php endforeach; ?>
</div></section>
<?php include __DIR__.'/../includes/layout_end.php'; ?>
