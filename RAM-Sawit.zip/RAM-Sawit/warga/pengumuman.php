<?php
require_once __DIR__ . '/../config/database.php';
require_login();
$title = 'Pengumuman';
$subtitle = 'Informasi resmi dari pengelola RAM';
require_once __DIR__ . '/../includes/public-list.php';
public_list($pdo, 'announce', 'Pengumuman Terkini', 'pengumuman');
