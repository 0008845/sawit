CREATE DATABASE IF NOT EXISTS ram_sawit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ram_sawit;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS log_aktivitas;
DROP TABLE IF EXISTS harga_tbs;
DROP TABLE IF EXISTS berita;
DROP TABLE IF EXISTS pengumuman;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS ram;
DROP TABLE IF EXISTS desa;
DROP TABLE IF EXISTS fitur_web;
DROP TABLE IF EXISTS pengaturan;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE desa(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(120) NOT NULL UNIQUE,kecamatan VARCHAR(120) NOT NULL DEFAULT 'Singkohor',alamat VARCHAR(255) NULL,status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE ram(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(150) NOT NULL,desa_id INT NOT NULL,alamat VARCHAR(255) NULL,kontak VARCHAR(50) NULL,status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_ram_desa FOREIGN KEY(desa_id) REFERENCES desa(id) ON UPDATE CASCADE ON DELETE RESTRICT) ENGINE=InnoDB;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(120) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,role ENUM('admin','user') NOT NULL DEFAULT 'user',desa_id INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_user_desa FOREIGN KEY(desa_id) REFERENCES desa(id) ON UPDATE CASCADE ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE harga_tbs(id INT AUTO_INCREMENT PRIMARY KEY,desa_id INT NOT NULL,ram_id INT NULL,tanggal DATE NOT NULL,harga_per_kg DECIMAL(12,2) NOT NULL,catatan TEXT NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_harga_desa FOREIGN KEY(desa_id) REFERENCES desa(id) ON UPDATE CASCADE ON DELETE RESTRICT,CONSTRAINT fk_harga_ram FOREIGN KEY(ram_id) REFERENCES ram(id) ON UPDATE CASCADE ON DELETE SET NULL,CONSTRAINT fk_harga_user FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL,INDEX idx_harga_tanggal(tanggal),INDEX idx_harga_desa_tanggal(desa_id,tanggal)) ENGINE=InnoDB;
CREATE TABLE pengumuman(id INT AUTO_INCREMENT PRIMARY KEY,judul VARCHAR(200) NOT NULL,isi TEXT NOT NULL,tanggal DATE NOT NULL,aktif TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE berita(id INT AUTO_INCREMENT PRIMARY KEY,judul VARCHAR(200) NOT NULL,ringkasan TEXT NOT NULL,isi MEDIUMTEXT NULL,tanggal DATE NOT NULL,status ENUM('Terbit','Draft') NOT NULL DEFAULT 'Terbit',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE pengaturan(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(100) NOT NULL UNIQUE,nilai TEXT NULL) ENGINE=InnoDB;
CREATE TABLE fitur_web(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(100) NOT NULL,path VARCHAR(190) NOT NULL UNIQUE,ikon VARCHAR(80) NOT NULL DEFAULT 'fa-puzzle-piece',role ENUM('admin','user','both') NOT NULL DEFAULT 'both',aktif TINYINT(1) NOT NULL DEFAULT 1,bawaan TINYINT(1) NOT NULL DEFAULT 0,urutan INT NOT NULL DEFAULT 100,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE log_aktivitas(id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL,aktivitas VARCHAR(255) NOT NULL,ip_address VARCHAR(64) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_log_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB;
INSERT INTO desa(nama,kecamatan,alamat) VALUES
('Lae Pinang','Singkohor','Desa di Kecamatan Singkohor, Kabupaten Aceh Singkil'),
('Lae Sipola','Singkohor','Desa di Kecamatan Singkohor, Kabupaten Aceh Singkil'),
('Mukti Jaya','Singkohor','Termasuk wilayah Mukti Harapan'),
('Pea Jambu','Singkohor','Desa di Kecamatan Singkohor, Kabupaten Aceh Singkil'),
('Singkohor','Singkohor','Desa di Kecamatan Singkohor, Kabupaten Aceh Singkil'),
('Sri Kayu','Singkohor','Desa di Kecamatan Singkohor, Kabupaten Aceh Singkil');
INSERT INTO ram(nama,desa_id,alamat,status) VALUES
('RAM Lae Pinang',1,'Alamat RAM perlu dilengkapi','Aktif'),
('RAM Lae Sipola',2,'Alamat RAM perlu dilengkapi','Aktif'),
('RAM Mukti Jaya',3,'Alamat RAM perlu dilengkapi','Aktif'),
('RAM Pea Jambu',4,'Alamat RAM perlu dilengkapi','Aktif'),
('RAM Singkohor',5,'Alamat RAM perlu dilengkapi','Aktif'),
('RAM Sri Kayu',6,'Alamat RAM perlu dilengkapi','Aktif');
-- Password awal: admin123 dan warga123. Ganti setelah login pertama.
INSERT INTO users(nama,email,password,role,desa_id) VALUES
('Administrator RAM','admin@ramsawit.com','$2y$12$Crr9FFrnrPywJquzHdBwOe3go3o9/6QbcDIDm4NAsojZx.rN8.WjG','admin',NULL),
('Warga Sawit','warga@ramsawit.com','$2y$12$1ik0VruFXQWfRN0VKun.s.IpsKcIwdiSnamOoR4JCmJsRdHvwDOeW','user',1);
INSERT INTO harga_tbs(desa_id,ram_id,tanggal,harga_per_kg,catatan) VALUES
(1,1,CURDATE(),2620,'Harga awal contoh; konfirmasi kepada RAM sebelum transaksi'),
(2,2,CURDATE(),2560,'Harga awal contoh; konfirmasi kepada RAM sebelum transaksi'),
(3,3,CURDATE(),2580,'Harga awal contoh; konfirmasi kepada RAM sebelum transaksi'),
(4,4,CURDATE(),2550,'Harga awal contoh; konfirmasi kepada RAM sebelum transaksi'),
(5,5,CURDATE(),2600,'Harga awal contoh; konfirmasi kepada RAM sebelum transaksi'),
(6,6,CURDATE(),2570,'Harga awal contoh; konfirmasi kepada RAM sebelum transaksi');
INSERT INTO pengumuman(judul,isi,tanggal,aktif) VALUES('Selamat datang di RAM Sawit','Sistem informasi harga TBS sawit telah tersedia. Silakan periksa tanggal pembaruan harga. ',CURDATE(),1);
INSERT INTO berita(judul,ringkasan,isi,tanggal,status) VALUES('Informasi Harga TBS Sawit','Pantau pembaruan harga melalui halaman Harga TBS.','Gunakan harga terbaru sebagai referensi awal dan konfirmasikan kepada RAM sebelum transaksi.',CURDATE(),'Terbit');
INSERT INTO pengaturan(nama,nilai) VALUES('nama_sistem','RAM Sawit'),('nama_pengelola','Rumpun Abdi Mandiri'),('kecamatan','Singkohor'),('deskripsi','Sistem informasi harga TBS sawit');
INSERT INTO fitur_web(nama,path,ikon,role,aktif,bawaan,urutan) VALUES
('Dashboard','dashboard.php','fa-chart-pie','both',1,1,1),
('Harga TBS','admin/harga-tbs.php','fa-tags','admin',1,1,2),
('Data Desa','admin/data-desa.php','fa-city','admin',1,1,3),
('Data RAM','admin/data-ram.php','fa-warehouse','admin',1,1,4),
('Pengumuman','admin/pengumuman.php','fa-bullhorn','admin',1,1,5),
('Berita','admin/berita.php','fa-newspaper','admin',1,1,6),
('Laporan','admin/laporan.php','fa-file-lines','admin',1,1,7),
('Pengguna','admin/pengguna.php','fa-users','admin',1,1,8),
('Pengaturan','admin/pengaturan.php','fa-gear','admin',1,1,9),
('Harga TBS','warga/harga-tbs.php','fa-tags','user',1,1,10),
('Database Desa & RAM','warga/desa.php','fa-map-location-dot','user',1,1,11),
('Kalkulator Panen','warga/kalkulator.php','fa-calculator','user',1,1,12),
('Pengumuman','warga/pengumuman.php','fa-bullhorn','user',1,1,13),
('Berita','warga/berita.php','fa-newspaper','user',1,1,14);
