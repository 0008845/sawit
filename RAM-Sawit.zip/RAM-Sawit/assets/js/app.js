document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{if(!confirm(el.dataset.confirm))e.preventDefault()}));
document.querySelectorAll('[data-filter]').forEach(input=>input.addEventListener('input',()=>{const q=input.value.toLowerCase();document.querySelectorAll(input.dataset.filter+' tbody tr').forEach(tr=>tr.hidden=!tr.innerText.toLowerCase().includes(q))}));
document.querySelectorAll('[data-menu-toggle]').forEach(b=>b.addEventListener('click',()=>document.body.classList.toggle('sidebar-open')));
// Search cards on warga's news and announcements pages.
document.querySelectorAll('[data-card-filter]').forEach(input=>input.addEventListener('input',()=>{const q=input.value.trim().toLocaleLowerCase('id');const container=document.getElementById(input.dataset.cardFilter);if(!container)return;const cards=[...container.querySelectorAll('.info-card')];let visible=0;cards.forEach(card=>{const match=card.innerText.toLocaleLowerCase('id').includes(q);card.hidden=!match;if(match)visible++});const empty=document.querySelector('[data-no-results]');if(empty)empty.hidden=visible!==0}));
// Gentle entrance animation for panels and dashboard cards.
document.querySelectorAll('.panel,.form-panel,.stat,.chart-panel').forEach((el,index)=>{if(!el.classList.contains('animate-in'))el.classList.add('animate-in');el.style.setProperty('--delay',`${Math.min(index,8)*45}ms`)});
// Small click feedback for navigation and buttons.
document.querySelectorAll('.btn,.nav-link').forEach(el=>{el.addEventListener('pointerdown',()=>{if(!el.matches(':disabled'))el.style.transform='scale(.98)'});['pointerup','pointerleave','pointercancel'].forEach(evt=>el.addEventListener(evt,()=>el.style.removeProperty('transform'))) });

document.querySelectorAll('[data-sidebar-collapse]').forEach(b=>b.addEventListener('click',()=>{document.body.classList.toggle('sidebar-collapsed');const collapsed=document.body.classList.contains('sidebar-collapsed');b.setAttribute('aria-label',collapsed?'Lebarkan sidebar':'Ciutkan sidebar');}));
document.querySelectorAll('.sidebar .nav-link').forEach(a=>a.addEventListener('click',()=>{if(window.matchMedia('(max-width: 900px)').matches)document.body.classList.remove('sidebar-open')}));


// Dark mode: pilihan tema disimpan di browser dan berlaku di seluruh dashboard.
(function(){
 const key='ram-sawit-theme';
 const apply=(mode)=>{
   document.body.classList.toggle('dark-mode',mode==='dark');
   document.querySelectorAll('[data-theme-toggle]').forEach(btn=>{
     const dark=mode==='dark';
     btn.innerHTML=dark?'<i class="fa-solid fa-sun"></i><span class="theme-label">Light mode</span>':'<i class="fa-solid fa-moon"></i><span class="theme-label">Dark mode</span>';
     btn.setAttribute('aria-label',dark?'Aktifkan mode terang':'Aktifkan mode gelap');
     btn.title=dark?'Aktifkan mode terang':'Aktifkan mode gelap';
   });
 };
 let saved='light';
 try{saved=localStorage.getItem(key)||'light'}catch(e){}
 apply(saved);
 document.querySelectorAll('[data-theme-toggle]').forEach(btn=>btn.addEventListener('click',()=>{
   const next=document.body.classList.contains('dark-mode')?'light':'dark';
   apply(next);try{localStorage.setItem(key,next)}catch(e){}
 }));
})();
